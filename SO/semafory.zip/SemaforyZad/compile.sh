#!/bin/bash 

gcc -o P1 P1.c
gcc -o P2 P2.c
gcc -o P3 P3.c
gcc main.c